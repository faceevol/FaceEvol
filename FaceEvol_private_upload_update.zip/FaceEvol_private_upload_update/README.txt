FaceEvol private upload update — 2026-08-28

FILES TO DEPLOY
1. Replace your repository root index.html with this index.html.
2. Add api/private-upload.js to your repository.
3. Keep your existing api/faceswap.js, api/prediction.js, api/video.mp4.js and api/age.js unchanged.
4. Your old api/upload.js can stay for now, but this new index.html no longer uses it for Video Face Swap uploads.

WHAT CHANGED
- Video selection is still limited to 20 seconds.
- Selected clips are trimmed in the browser.
- If needed, the selected clip is H.264/AAC compressed in the browser to fit safely below the Vercel Function request-body limit.
- Face photos are optimized below ~1.2 MB.
- Video and face are POSTed to /api/private-upload as raw binary.
- /api/private-upload uses @vercel/blob put() server-to-server with access: "private".
- The browser no longer uses @vercel/blob/client for Video Face Swap uploads.

DEPENDENCY
Your project needs @vercel/blob. If your existing project already imports @vercel/blob in API routes, you already have it. If Vercel reports that the module is missing, install the current @vercel/blob package and redeploy.

IMPORTANT
Vercel Functions have a 4.5 MB request-body limit. The browser intentionally targets ~3.2 MB for the video and ~1.2 MB for the face to leave headroom.
